from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, Settings
from llama_index.core.node_parser import SentenceSplitter
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding

# 設定本地模型（LLM 用於回答，Embedding 用於檢索）
Settings.llm = Ollama(model="qwen2.5:3b-instruct-q4_K_M", request_timeout=180.0)
Settings.embed_model = OllamaEmbedding(model_name="nomic-embed-text")

print("讀取專案檔案中...")
documents = SimpleDirectoryReader(
    input_dir="D:/codespace/clean_code",  # 程式碼最外層目錄
    required_exts=[
        ".cs", ".aspx", ".ashx", ".ascx", ".master", ".config",
        ".xsd", ".js", ".rdlc", ".cshtml", ".svc", ".json", ".wsdl"
    ],
    recursive=True
).load_data()
print(f"共讀取 {len(documents)} 個檔案")

# 依固定字元數切割程式碼（不需要語法解析器，穩定可靠）
splitter = SentenceSplitter(
    chunk_size=1000,
    chunk_overlap=100
)

print("建立向量索引中...")
print(f"（依經驗，純 CPU 環境每個片段約需 0.5~2 秒，實際時間依電腦狀況而定）")

import time
start_time = time.time()

index = VectorStoreIndex.from_documents(
    documents,
    transformations=[splitter],
    show_progress=True  # 顯示進度條，方便估算剩餘時間
)

elapsed = time.time() - start_time
print(f"建立索引耗時：{elapsed/60:.1f} 分鐘")

# 存到本地磁碟，之後不用重建
index.storage_context.persist(persist_dir="./storage")
print("索引建立完成，已存到 ./storage 資料夾")

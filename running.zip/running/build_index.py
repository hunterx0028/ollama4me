from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, Settings
from llama_index.core.node_parser import CodeSplitter
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding

# 設定本地模型（LLM 用於回答，Embedding 用於檢索）
Settings.llm = Ollama(model="qwen2.5:3b-instruct-q4_K_M", request_timeout=180.0)
Settings.embed_model = OllamaEmbedding(model_name="nomic-embed-text")

print("讀取專案檔案中...")
documents = SimpleDirectoryReader(
    input_dir="D:/codespace/clean_code",  # 換成實際路徑
    required_exts=[".cs"],
    recursive=True
).load_data()
print(f"共讀取 {len(documents)} 個檔案")

# 依類別/方法邊界切割程式碼
splitter = CodeSplitter(
    language="c_sharp",
    chunk_lines=60,
    chunk_lines_overlap=10,
    max_chars=1500
)

print("建立向量索引中（依檔案數量，可能需要幾分鐘）...")
index = VectorStoreIndex.from_documents(documents, transformations=[splitter])

# 存到本地磁碟，之後不用重建
index.storage_context.persist(persist_dir="./storage")
print("索引建立完成，已存到 ./storage 資料夾")
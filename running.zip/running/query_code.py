from llama_index.core import StorageContext, load_index_from_storage, Settings
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding
import sys
import json
import os

CONFIG_FILE = ".query_code_config.json"
FALLBACK_DEFAULT = 3  # 從來沒設定過任何值時，最初始的預設值

# 設定本地模型（LLM 用於回答，Embedding 用於檢索）
Settings.llm = Ollama(model="qwen2.5:3b-instruct-q4_K_M", request_timeout=180.0)
Settings.embed_model = OllamaEmbedding(model_name="nomic-embed-text")

# 讀取已建立好的向量索引
storage_context = StorageContext.from_defaults(persist_dir="./storage")
index = load_index_from_storage(storage_context)


def load_last_top_k():
    """讀取上次使用的 top_k，找不到設定檔就用最初始的預設值"""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return int(data.get("last_top_k", FALLBACK_DEFAULT))
        except (json.JSONDecodeError, ValueError):
            return FALLBACK_DEFAULT
    return FALLBACK_DEFAULT


def save_last_top_k(top_k):
    """把這次用的 top_k 存起來，當作下次的預設值"""
    with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
        json.dump({"last_top_k": top_k}, f)


def parse_args(args, default_top_k):
    """
    判斷最後一個參數是否為數字（top_k）。
    是 -> 拆分出來當 top_k，第一個參數當問題
    不是 -> top_k 使用傳入的預設值，第一個參數當問題
    """
    top_k = default_top_k
    if len(args) >= 2 and args[-1].isdigit():
        top_k = int(args[-1])
    question = args[0]
    return question, top_k


if __name__ == '__main__':
    default_top_k = load_last_top_k()

    if len(sys.argv) > 1:
        question, top_k = parse_args(sys.argv[1:], default_top_k)
    else:
        question = input("請輸入問題：")
        top_k_input = input(f"請輸入 top_k（直接按 Enter 使用上次的值 {default_top_k}）：")
        top_k = int(top_k_input) if top_k_input.strip().isdigit() else default_top_k

    print(f"[使用 top_k={top_k}]")
    query_engine = index.as_query_engine(similarity_top_k=top_k)
    response = query_engine.query(question)
    print(response)

    # 把這次用的值存起來，當作下次的預設值
    save_last_top_k(top_k)
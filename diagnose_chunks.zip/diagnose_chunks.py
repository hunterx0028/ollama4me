from llama_index.core import SimpleDirectoryReader
from llama_index.core.node_parser import SentenceSplitter

ROOT_DIR = "D:/codespace/clean_code"

documents = SimpleDirectoryReader(
    input_dir=ROOT_DIR,
    required_exts=[
        ".cs", ".aspx", ".ashx", ".ascx", ".master", ".config",
        ".xsd", ".js", ".rdlc", ".cshtml", ".svc", ".json", ".wsdl"
    ],
    recursive=True
).load_data()

splitter = SentenceSplitter(chunk_size=1000, chunk_overlap=100)
nodes = splitter.get_nodes_from_documents(documents)

lengths = [(len(n.get_content()), n.metadata.get('file_path', '未知檔案')) for n in nodes]
lengths.sort(reverse=True)

print(f"共 {len(nodes)} 個片段\n")
print("最大的 10 個片段：")
print(f"{'字元數':<10}{'檔案路徑'}")
print("-" * 60)
for length, path in lengths[:10]:
    print(f"{length:<10}{path}")

print(f"\n平均長度：{sum(l for l, _ in lengths) / len(lengths):.0f} 字元")

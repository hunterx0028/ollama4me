from llama_index.core import StorageContext, load_index_from_storage, Settings
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding
import json
import os

CONFIG_FILE = ".query_code_config.json"
FALLBACK_DEFAULT = 3

Settings.llm = Ollama(model="qwen2.5:3b-instruct-q4_K_M", request_timeout=180.0)
Settings.embed_model = OllamaEmbedding(model_name="nomic-embed-text")


def load_last_top_k():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return int(data.get("last_top_k", FALLBACK_DEFAULT))
        except (json.JSONDecodeError, ValueError):
            return FALLBACK_DEFAULT
    return FALLBACK_DEFAULT


def save_last_top_k(top_k):
    with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
        json.dump({"last_top_k": top_k}, f)


print("讀取索引中，請稍候...")
storage_context = StorageContext.from_defaults(persist_dir="./storage")
index = load_index_from_storage(storage_context)
print("索引載入完成！之後的提問不用再重新載入。\n")

top_k = load_last_top_k()
print(f"目前 top_k = {top_k}（可在提問時輸入新數字更改，例如：問題內容 10）\n")
print("輸入問題開始查詢，輸入 exit 或 quit 結束。\n")

while True:
    user_input = input(">>> ").strip()

    if user_input.lower() in ("exit", "quit"):
        print("結束查詢。")
        break

    if not user_input:
        continue

    # 檢查最後一個詞是否為數字，是的話當作這次的 top_k
    parts = user_input.rsplit(" ", 1)
    if len(parts) == 2 and parts[1].isdigit():
        question = parts[0]
        top_k = int(parts[1])
        save_last_top_k(top_k)
    else:
        question = user_input

    print(f"[使用 top_k={top_k}] 查詢中...")
    query_engine = index.as_query_engine(similarity_top_k=top_k)
    response = query_engine.query(question)
    print(f"\n{response}\n")

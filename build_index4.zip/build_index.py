from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, Settings
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding

# 設定本地模型（LLM 用於回答，Embedding 用於檢索）
Settings.llm = Ollama(model="qwen2.5:3b-instruct-q4_K_M", request_timeout=180.0)
Settings.embed_model = OllamaEmbedding(model_name="nomic-embed-text")

print("讀取專案檔案中...")
documents = SimpleDirectoryReader(
    input_dir="D:/codespace/clean_code",  # 程式碼最外層目錄
    required_exts=[
        ".cs", ".aspx", ".ashx", ".ascx", ".master", ".config",
        ".xsd", ".js", ".cshtml", ".svc", ".json", ".wsdl"
    ],
    recursive=True
).load_data()
print(f"共讀取 {len(documents)} 個檔案")

# 依固定 token 數強制切割（不管內容有沒有句子邊界，一律切開，避免超大片段）
splitter = TokenTextSplitter(
    chunk_size=500,      # 約略對應 1000 字元左右（1 token 約 1.5-2 中文字元）
    chunk_overlap=50
)

print("切割文件成片段中...")
nodes = splitter.get_nodes_from_documents(documents)
total = len(nodes)
print(f"共產生 {total} 個片段（chunks），這是 embedding 會處理的總數")

print("開始逐一計算 embedding...")
from tqdm import tqdm
import time

start_time = time.time()

for node in tqdm(nodes, total=total, desc="Embedding 進度", unit="片段"):
    node.embedding = Settings.embed_model.get_text_embedding(node.get_content())

elapsed = time.time() - start_time
print(f"\n全部 embedding 計算完成，耗時：{elapsed/60:.1f} 分鐘")

# 因為 node 已經帶有 embedding，這一步不會重新計算，只是把資料組進索引結構
print("組裝索引中...")
index = VectorStoreIndex(nodes, show_progress=False)

# 存到本地磁碟，之後不用重建
index.storage_context.persist(persist_dir="./storage")
print("索引建立完成，已存到 ./storage 資料夾")

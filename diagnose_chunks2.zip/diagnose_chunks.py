from llama_index.core import SimpleDirectoryReader
from llama_index.core.node_parser import TokenTextSplitter

ROOT_DIR = "D:/codespace/clean_code"

documents = SimpleDirectoryReader(
    input_dir=ROOT_DIR,
    required_exts=[
        ".cs", ".aspx", ".ashx", ".ascx", ".master", ".config",
        ".xsd", ".js", ".cshtml", ".svc", ".json", ".wsdl"
    ],
    recursive=True
).load_data()

splitter = TokenTextSplitter(chunk_size=500, chunk_overlap=50)
nodes = splitter.get_nodes_from_documents(documents)

lengths = [(len(n.get_content()), n.metadata.get('file_path', '未知檔案')) for n in nodes]
lengths.sort(reverse=True)

print(f"共 {len(nodes)} 個片段\n")
print("最大的 10 個片段：")
print(f"{'字元數':<10}{'檔案路徑'}")
print("-" * 60)
for length, path in lengths[:10]:
    print(f"{length:<10}{path}")

print(f"\n平均長度：{sum(l for l, _ in lengths) / len(lengths):.0f} 字元")

# 找出最大片段的完整內容，印出開頭 300 字元，方便判斷是什麼內容
max_node = max(nodes, key=lambda n: len(n.get_content()))
print(f"\n最大片段所在檔案：{max_node.metadata.get('file_path', '未知')}")
print(f"該片段長度：{len(max_node.get_content())} 字元")
print(f"內容開頭預覽：\n{max_node.get_content()[:300]}")

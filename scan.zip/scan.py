import os
from collections import Counter

# 換成你的專案最外層目錄
ROOT_DIR = "D:/codespace/clean_code"

def scan_extensions(root_dir):
    counter = Counter()
    for dirpath, _, filenames in os.walk(root_dir):
        for filename in filenames:
            _, ext = os.path.splitext(filename)
            ext = ext.lower() if ext else "(無副檔名)"
            counter[ext] += 1
    return counter

if __name__ == '__main__':
    result = scan_extensions(ROOT_DIR)

    if not result:
        print("找不到任何檔案，請確認路徑是否正確。")
    else:
        print(f"掃描路徑：{ROOT_DIR}\n")
        print(f"{'副檔名':<15}{'檔案數量'}")
        print("-" * 25)
        # 依數量由多到少排序
        for ext, count in sorted(result.items(), key=lambda x: -x[1]):
            print(f"{ext:<15}{count}")
        print("-" * 25)
        print(f"總檔案數：{sum(result.values())}")